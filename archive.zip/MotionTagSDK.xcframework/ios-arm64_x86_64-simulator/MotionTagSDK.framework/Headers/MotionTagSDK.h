
#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double MotionTagSDKVersionNumber;

FOUNDATION_EXPORT const unsigned char MotionTagSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MotionTagLib/PublicHeader.h>

#import "MotionTag.h"
